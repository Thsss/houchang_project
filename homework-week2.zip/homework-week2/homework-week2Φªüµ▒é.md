# Homework-week2
## 1. 补全rnn_encoder.py，完成Encoder的结构

## 2. 补全rnn_decoder.py，完成Attention和Decoder的结构

## 3. 完成sequence_to_sequence.py

## 4. python ./seq2seq_tf2/bin/main.py看看能不能把整个模型的训练跑通哟！



