# from encoders.rnn_encoder import Encoder
# from seq2seq_pgn_tf2.encoders.rnn_encoder import Encoder
#coding=utf-8